basho = function(){
    haiku = c(
        "草の戸も　住み替はる代ぞ　ひなの家",
        "夏草や　兵どもが　夢の跡",
        "五月雨の　降り残してや　光堂",
        "閑かさや　岩にしみ入る　蝉の声",
        "五月雨を　あつめて早し　最上川")
            
    no = as.integer(runif(1,0,length(haiku)))
    
    if(no==0){
        cat("曾良：病僧の　庭はく梅の　さかり哉\n")
    }else{
        cat(paste0("芭蕉：",haiku[no],"\n"))
    }
}

for(i in 1:10){
    basho()
}
